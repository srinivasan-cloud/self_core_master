package com.selfxdsd.api;

/**
 * Provider repos.
 * @author criske
 * @version $Id$
 * @since 0.0.8
 */
public interface Repos extends Iterable<Repo> {
}
